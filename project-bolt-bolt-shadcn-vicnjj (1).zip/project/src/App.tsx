import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from "@/components/theme-provider";
import { LoginForm } from "@/components/auth/login-form";
import { ThemeToggle } from "@/components/theme-toggle";
import { ReadingsView } from "@/components/dashboard/readings-view";
import { SchematicView } from "@/components/dashboard/schematic-view";
import { UserManagement } from "@/components/dashboard/user-management";
import { FactoryBackground } from "@/components/animations/factory-background";
import { motion } from "framer-motion";
import { Toaster } from "@/components/ui/sonner";
import { AuthGuard } from "@/components/auth/auth-guard";
import { AdminDashboard } from "@/components/dashboard/admin-dashboard";
import { EngineerDashboard } from "@/components/dashboard/engineer-dashboard";

function LandingPage() {
  return (
    <div className="min-h-screen relative overflow-hidden">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="fixed top-4 right-4 z-50"
      >
        <ThemeToggle />
      </motion.div>
      
      <Toaster />
      
      {/* Factory Background Animation */}
      <FactoryBackground />
      
      {/* Content */}
      <div className="min-h-screen flex items-center justify-center relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="w-full max-w-md mx-auto p-8"
        >
          <div className="glass-card rounded-2xl p-8">
            <LoginForm />
          </div>
        </motion.div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="ngfe-theme">
      <Router>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route
            path="/admin"
            element={
              <AuthGuard allowedRoles={['admin']}>
                <AdminDashboard />
              </AuthGuard>
            }
          />
          <Route
            path="/admin/users"
            element={
              <AuthGuard allowedRoles={['admin']}>
                <UserManagement />
              </AuthGuard>
            }
          />
          <Route
            path="/engineer"
            element={
              <AuthGuard allowedRoles={['engineer']}>
                <EngineerDashboard />
              </AuthGuard>
            }
          />
          <Route
            path="/engineer/readings"
            element={
              <AuthGuard allowedRoles={['engineer']}>
                <ReadingsView />
              </AuthGuard>
            }
          />
          <Route
            path="/engineer/schematic"
            element={
              <AuthGuard allowedRoles={['engineer']}>
                <SchematicView />
              </AuthGuard>
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
      <Toaster />
    </ThemeProvider>
  );
}