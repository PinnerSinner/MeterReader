import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Activity, AlertTriangle, CheckCircle2, Clock } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { formatDistanceToNow } from "date-fns";
import { useNavigate } from "react-router-dom";

const activityIcons = {
  reading_submitted: CheckCircle2,
  maintenance_required: Activity,
  alert: AlertTriangle,
};

const activityColors = {
  reading_submitted: "text-green-500",
  maintenance_required: "text-orange-500",
  alert: "text-red-500",
};

export function RecentActivity() {
  const activities = useStore((state) => state.activities);
  const navigate = useNavigate();

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-semibold">Recent Activity</h3>
          <p className="text-sm text-muted-foreground">Latest meter readings and alerts</p>
        </div>
        <Button 
          variant="ghost" 
          size="sm" 
          className="gap-2"
          onClick={() => navigate("/engineer/activity")}
        >
          <Clock className="h-4 w-4" />
          View All
        </Button>
      </div>

      <div className="space-y-4">
        <AnimatePresence mode="popLayout">
          {activities.slice(0, 5).map((activity) => {
            const Icon = activityIcons[activity.type];
            const colorClass = activityColors[activity.type];

            return (
              <motion.div
                key={activity.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -100 }}
                className="flex items-start gap-4 p-3 rounded-lg bg-muted/50"
              >
                <div className={`${colorClass} p-2 rounded-full bg-background`}>
                  <Icon className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{activity.title}</p>
                  <p className="text-sm text-muted-foreground truncate">
                    {activity.description}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>

        {activities.length === 0 && (
          <div className="text-center py-6 text-muted-foreground">
            <p>No recent activity</p>
          </div>
        )}
      </div>
    </Card>
  );
}