import { motion } from "framer-motion";
import { Factory, Gauge, Settings, Activity, Cog, Cpu } from "lucide-react";
import { useEffect, useState } from "react";

interface Symbol {
  id: number;
  x: number;
  y: number;
  speed: number;
  icon: JSX.Element;
  size: number;
  opacity: number;
}

export function FactoryBackground() {
  const [symbols, setSymbols] = useState<Symbol[]>([]);

  useEffect(() => {
    const icons = [
      <Factory size={24} />,
      <Gauge size={24} />,
      <Settings size={24} />,
      <Activity size={24} />,
      <Cog size={24} />,
      <Cpu size={24} />,
    ];

    const newSymbols = Array.from({ length: 50 }, (_, i) => ({
      id: i,
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight * -1,
      speed: 1 + Math.random() * 2,
      icon: icons[Math.floor(Math.random() * icons.length)],
      size: 16 + Math.random() * 16,
      opacity: 0.1 + Math.random() * 0.3,
    }));

    setSymbols(newSymbols);

    const interval = setInterval(() => {
      setSymbols(prev => prev.map(symbol => ({
        ...symbol,
        y: symbol.y + symbol.speed,
        ...(symbol.y > window.innerHeight ? {
          y: -50,
          x: Math.random() * window.innerWidth,
        } : {})
      })));
    }, 1000 / 30);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 bg-background overflow-hidden">
      {/* Grid Background */}
      <div className="absolute inset-0 bg-grid opacity-5" />

      {/* Gradient Overlays */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/20 to-transparent opacity-30" />
      <div className="absolute inset-0 bg-gradient-to-r from-accent/20 via-transparent to-accent/20 opacity-30" />

      {/* Falling Symbols */}
      {symbols.map((symbol) => (
        <motion.div
          key={symbol.id}
          className="absolute text-primary/30"
          style={{
            left: symbol.x,
            top: symbol.y,
            opacity: symbol.opacity,
          }}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          {symbol.icon}
        </motion.div>
      ))}

      {/* Floating Orbs */}
      <motion.div
        className="absolute w-96 h-96 rounded-full blur-3xl"
        style={{
          background: "radial-gradient(circle, rgba(139, 92, 246, 0.15) 0%, transparent 70%)",
          top: "20%",
          left: "30%",
        }}
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute w-96 h-96 rounded-full blur-3xl"
        style={{
          background: "radial-gradient(circle, rgba(139, 92, 246, 0.15) 0%, transparent 70%)",
          bottom: "20%",
          right: "30%",
        }}
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.2, 0.4, 0.2],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
    </div>
  );
}