import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Activity } from "@/lib/store";
import { formatDistanceToNow } from "date-fns";
import { AlertTriangle, CheckCircle2, Clock, Activity as ActivityIcon } from "lucide-react";

interface ActivityFeedProps {
  activities: Activity[];
  limit?: number;
  showViewAll?: boolean;
  onViewAll?: () => void;
}

const activityIcons = {
  reading_submitted: CheckCircle2,
  maintenance_required: ActivityIcon,
  alert: AlertTriangle,
  review_requested: Clock,
  review_completed: CheckCircle2,
};

const activityStyles = {
  reading_submitted: "text-green-500 bg-green-500/10",
  maintenance_required: "text-orange-500 bg-orange-500/10",
  alert: "text-red-500 bg-red-500/10",
  review_requested: "text-blue-500 bg-blue-500/10",
  review_completed: "text-purple-500 bg-purple-500/10",
};

export function ActivityFeed({
  activities,
  limit,
  showViewAll = false,
  onViewAll,
}: ActivityFeedProps) {
  const displayedActivities = limit ? activities.slice(0, limit) : activities;

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="space-y-1">
          <h3 className="font-semibold">Recent Activity</h3>
          <p className="text-sm text-muted-foreground">
            Latest updates and notifications
          </p>
        </div>
        {showViewAll && onViewAll && (
          <Button
            variant="ghost"
            size="sm"
            className="gap-2"
            onClick={onViewAll}
          >
            <Clock className="h-4 w-4" />
            View All
          </Button>
        )}
      </div>

      <div className="space-y-4">
        <AnimatePresence mode="popLayout">
          {displayedActivities.map((activity) => {
            const Icon = activityIcons[activity.type] || ActivityIcon;
            const styles = activityStyles[activity.type] || "text-primary bg-primary/10";

            return (
              <motion.div
                key={activity.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -100 }}
                className="flex items-start gap-4 p-4 rounded-lg bg-muted/50"
              >
                <div className={`p-2 rounded-full ${styles}`}>
                  <Icon className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0 space-y-1">
                  <p className="font-medium truncate">{activity.title}</p>
                  <p className="text-sm text-muted-foreground truncate">
                    {activity.description}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>

        {displayedActivities.length === 0 && (
          <div className="text-center py-6 text-muted-foreground">
            <p>No recent activity</p>
          </div>
        )}
      </div>
    </Card>
  );
}