import { useState } from "react";
import { motion } from "framer-motion";
import {
  Users,
  Gauge,
  ClipboardCheck,
  BarChart3,
  Filter,
  Download,
  FileText,
  AlertTriangle,
  MoreHorizontal,
  Calendar,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { DashboardLayout } from "./layout";
import { useStore } from "@/lib/store";
import { StatsCard } from "./stats-card";
import { DataTable } from "./data-table";
import { ActivityFeed } from "./activity-feed";
import { format, startOfWeek, endOfWeek } from "date-fns";
import { TimelineChart } from "./timeline-chart";
import { SLAMetrics } from "./sla-metrics";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ReadingReview } from "./reading-review";
import { toast } from "sonner";

export function AdminDashboard() {
  const {
    readings,
    activities,
    meters,
    getPendingReviews,
    getTodaysReadings,
    getPendingMaintenance,
    updateReadingReview,
  } = useStore();

  const currentWeek = {
    start: startOfWeek(new Date()),
    end: endOfWeek(new Date()),
  };

  const stats = {
    totalUsers: 2,
    activeMeters: meters.filter((m) => !m.maintenanceRequired).length,
    pendingReviews: getPendingReviews().length,
    todaysReadings: getTodaysReadings().length,
  };

  const slaMetrics = {
    responseTime: 98.5,
    uptime: 99.9,
    accuracy: 97.2,
    compliance: 95.8,
  };

  const handleReviewAction = (readingId: string, status: 'approved' | 'rejected', note: string) => {
    updateReadingReview(readingId, status, note, "Sarah Admin");
    toast.success(`Reading ${status}`, {
      description: `The reading has been ${status} successfully.`
    });
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-semibold">Dashboard</h1>
            <div className="flex items-center gap-2 px-4 py-1 bg-muted rounded-full text-sm text-muted-foreground">
              <Calendar className="h-4 w-4" />
              {format(currentWeek.start, "MMM d, yyyy")} — {format(currentWeek.end, "MMM d, yyyy")}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" className="gap-2">
              <Filter className="h-4 w-4" />
              Filter
            </Button>
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Total Users"
            value={stats.totalUsers}
            icon={<Users className="h-6 w-6 text-primary" />}
          />
          <StatsCard
            title="Active Meters"
            value={stats.activeMeters}
            icon={<Gauge className="h-6 w-6 text-green-500" />}
          />
          <StatsCard
            title="Pending Reviews"
            value={stats.pendingReviews}
            icon={<AlertTriangle className="h-6 w-6 text-orange-500" />}
          />
          <StatsCard
            title="Today's Readings"
            value={stats.todaysReadings}
            icon={<ClipboardCheck className="h-6 w-6 text-blue-500" />}
          />
        </div>

        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="reviews">Reading Reviews</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-6 lg:grid-cols-3">
              {/* Main Content - 2 Columns */}
              <div className="lg:col-span-2 space-y-6">
                {/* Timeline Chart */}
                <div className="rounded-xl border bg-card p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h2 className="text-lg font-semibold">Reading Timeline</h2>
                      <p className="text-sm text-muted-foreground">Daily meter reading activity</p>
                    </div>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </div>
                  <TimelineChart data={readings} />
                </div>

                {/* Recent Readings Table */}
                <div className="rounded-xl border bg-card p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h2 className="text-lg font-semibold">Recent Readings</h2>
                      <p className="text-sm text-muted-foreground">
                        Latest meter readings across all locations
                      </p>
                    </div>
                  </div>
                  <DataTable
                    data={readings.slice(0, 5)}
                    columns={[
                      { header: "Meter ID", accessorKey: "meterId" },
                      { header: "Type", accessorKey: "type" },
                      { header: "Value", accessorKey: "value" },
                      { header: "Engineer", accessorKey: "engineer" },
                      {
                        header: "Status",
                        accessorKey: "reviewStatus",
                        cell: (value) => (
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            value === "pending" 
                              ? "bg-orange-100 text-orange-700" 
                              : value === "approved"
                              ? "bg-green-100 text-green-700"
                              : value === "rejected"
                              ? "bg-red-100 text-red-700"
                              : "bg-blue-100 text-blue-700"
                          }`}>
                            {value || "completed"}
                          </span>
                        ),
                      },
                      {
                        header: "Time",
                        accessorKey: "timestamp",
                        cell: (value) => format(new Date(value), "h:mm a"),
                      },
                    ]}
                  />
                </div>
              </div>

              {/* Right Sidebar */}
              <div className="space-y-6">
                {/* SLA Metrics */}
                <SLAMetrics metrics={slaMetrics} />

                {/* Activity Feed */}
                <ActivityFeed
                  activities={activities.slice(0, 4)}
                  showViewAll
                  onViewAll={() => {}}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="reviews">
            <ReadingReview
              readings={getPendingReviews()}
              onApprove={(id, note) => handleReviewAction(id, 'approved', note)}
              onReject={(id, note) => handleReviewAction(id, 'rejected', note)}
            />
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}