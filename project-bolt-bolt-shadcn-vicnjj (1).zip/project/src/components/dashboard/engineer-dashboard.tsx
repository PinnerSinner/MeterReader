import { useState } from "react";
import { motion } from "framer-motion";
import {
  Activity,
  Gauge,
  Settings,
  Download,
  Filter,
  Plus,
  Search,
  MoreVertical,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useStore } from "@/lib/store";
import { useAuth } from "@/lib/auth";
import { DashboardLayout } from "./layout";
import { MeterReadingForm } from "@/components/meter-reading/meter-form";
import { FactorySchematic } from "@/components/schematic/factory-schematic";
import { StatsCard } from "./stats-card";
import { DataTable } from "./data-table";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";

export function EngineerDashboard() {
  const { user } = useAuth();
  const {
    readings,
    meters,
    getTodaysReadings,
    getPendingMaintenance,
  } = useStore();

  const [isAddingReading, setIsAddingReading] = useState(false);
  const [selectedReading, setSelectedReading] = useState<any>(null);

  const pendingReviews = readings.filter(
    (r) => r.reviewStatus === "pending" && r.engineer === user?.name
  );

  const stats = {
    totalReadings: readings.length,
    activeMeters: `${meters.filter(m => !m.maintenanceRequired).length} of ${meters.length}`,
    maintenanceDue: getPendingMaintenance().length,
  };

  const handleExport = () => {
    const csvContent = [
      // CSV Headers
      ["Meter ID", "Type", "Value", "Location", "Date", "Status"].join(","),
      // CSV Data
      ...readings.map(reading => [
        reading.meterId,
        reading.type,
        reading.value,
        reading.location,
        format(new Date(reading.timestamp), "yyyy-MM-dd HH:mm:ss"),
        reading.reviewStatus || "completed"
      ].join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `readings_${format(new Date(), "yyyy-MM-dd")}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleAction = (action: string, reading: any) => {
    switch (action) {
      case "view":
        setSelectedReading(reading);
        break;
      case "edit":
        // Implement edit functionality
        toast.info("Edit functionality coming soon");
        break;
      case "review":
        toast.info(`Requesting review for reading ${reading.meterId}`);
        break;
      default:
        break;
    }
  };

  const columns = [
    { 
      header: "Meter ID",
      accessorKey: "meterId",
      cell: (value: string) => (
        <div className="font-medium">{value}</div>
      ),
    },
    { 
      header: "Location",
      accessorKey: "location",
      cell: (value: string) => (
        <div className="text-muted-foreground">{value}</div>
      ),
    },
    {
      header: "Reading Date",
      accessorKey: "timestamp",
      cell: (value: string) => format(new Date(value), "MMM dd, yyyy"),
    },
    {
      header: "Value",
      accessorKey: "value",
      cell: (value: number, row: any) => (
        <div className="font-medium">
          {value} {row.type === "temperature" ? "°C" : "kW"}
        </div>
      ),
    },
    {
      header: "Status",
      accessorKey: "reviewStatus",
      cell: (value: string) => (
        <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
          value === "pending"
            ? "bg-yellow-100 text-yellow-800"
            : value === "approved"
            ? "bg-green-100 text-green-800"
            : value === "rejected"
            ? "bg-red-100 text-red-800"
            : "bg-blue-100 text-blue-800"
        }`}>
          {value || "completed"}
        </div>
      ),
    },
    {
      header: "Actions",
      accessorKey: "id",
      cell: (value: string, row: any) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm">
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => handleAction("view", row)}>
              View Details
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleAction("edit", row)}>
              Edit Reading
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleAction("review", row)}>
              Request Review
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Overview</h1>
            <p className="text-muted-foreground">
              Key performance indicators and critical metrics
            </p>
          </div>
          <Dialog open={isAddingReading} onOpenChange={setIsAddingReading}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Add Reading
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Submit New Reading</DialogTitle>
                <DialogDescription>
                  Enter the meter details and current reading value.
                </DialogDescription>
              </DialogHeader>
              <MeterReadingForm onSuccess={() => setIsAddingReading(false)} />
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <StatsCard
            title="Total Readings"
            value={stats.totalReadings}
            icon={<Activity className="h-6 w-6 text-primary" />}
          />
          <StatsCard
            title="Active Meters"
            value={stats.activeMeters}
            icon={<Gauge className="h-6 w-6 text-green-500" />}
          />
          <StatsCard
            title="Maintenance Due"
            value={stats.maintenanceDue}
            icon={<Settings className="h-6 w-6 text-orange-500" />}
          />
        </div>

        <div className="rounded-lg border bg-card">
          <div className="p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Inspection</h2>
              <div className="flex items-center gap-4">
                <Button variant="outline" className="gap-2" onClick={handleExport}>
                  <Download className="h-4 w-4" />
                  Export Data
                </Button>
                <Button variant="outline" className="gap-2">
                  <Filter className="h-4 w-4" />
                  Filter
                </Button>
              </div>
            </div>

            <DataTable
              data={readings}
              columns={columns}
              searchPlaceholder="Search readings..."
              filterOptions={[
                { label: "Pending Review", value: "pending" },
                { label: "Approved", value: "approved" },
                { label: "Maintenance", value: "maintenance" },
              ]}
              onExport={handleExport}
            />
          </div>
        </div>

        <div className="rounded-lg border bg-card p-6">
          <FactorySchematic onMeterClick={(meterId) => {
            setIsAddingReading(true);
          }} />
        </div>
      </div>
    </DashboardLayout>
  );
}