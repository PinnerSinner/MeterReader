import { UserNav } from "@/components/layout/user-nav";
import { ThemeToggle } from "@/components/theme-toggle";
import { Toaster } from "@/components/ui/sonner";
import { Breadcrumbs } from "@/components/navigation/breadcrumbs";
import { Sidebar } from "@/components/navigation/sidebar";
import { motion } from "framer-motion";
import { Separator } from "@/components/ui/separator";

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <div className="min-h-screen flex dark:bg-gray-950">
      {/* Sidebar */}
      <motion.div
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        className="hidden lg:block w-64 border-r border-border"
      >
        <Sidebar />
      </motion.div>

      {/* Main Content */}
      <div className="flex-1">
        <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-sm">
          <div className="flex h-16 items-center px-6">
            <Breadcrumbs />
            <div className="ml-auto flex items-center gap-4">
              <div className="flex items-center gap-4">
                <Separator orientation="vertical" className="h-6" />
                <ThemeToggle />
                <UserNav />
              </div>
            </div>
          </div>
        </header>
        
        <main className="p-6">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.2 }}
          >
            {children}
          </motion.div>
        </main>
      </div>
      
      <Toaster />
    </div>
  );
}