import { motion } from "framer-motion";

interface ProgressCircleProps {
  value: number;
  label: string;
  color?: string;
}

export function ProgressCircle({ value, label, color = "bg-primary" }: ProgressCircleProps) {
  const circumference = 2 * Math.PI * 38; // radius = 38
  const offset = circumference - (value / 100) * circumference;

  return (
    <div className="flex items-center gap-4">
      <div className="relative w-20 h-20">
        {/* Background circle */}
        <svg className="w-full h-full -rotate-90">
          <circle
            cx="40"
            cy="40"
            r="38"
            fill="none"
            stroke="currentColor"
            strokeWidth="4"
            className="opacity-10"
          />
          {/* Progress circle */}
          <motion.circle
            cx="40"
            cy="40"
            r="38"
            fill="none"
            stroke="currentColor"
            strokeWidth="4"
            className={color}
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: offset }}
            transition={{ duration: 1, ease: "easeOut" }}
          />
        </svg>
        {/* Percentage text */}
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-lg font-semibold">{value}%</span>
        </div>
      </div>
      <div>
        <p className="text-sm font-medium">{label}</p>
        <p className="text-xs text-muted-foreground">Last 7 days</p>
      </div>
    </div>
  );
}