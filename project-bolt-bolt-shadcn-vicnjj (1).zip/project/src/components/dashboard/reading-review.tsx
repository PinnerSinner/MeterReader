import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { CheckCircle, XCircle, AlertTriangle, Image as ImageIcon } from "lucide-react";
import { Reading } from "@/lib/store";
import { format } from "date-fns";
import { motion } from "framer-motion";

interface ReadingReviewProps {
  readings: Reading[];
  onApprove: (id: string, note: string) => void;
  onReject: (id: string, note: string) => void;
}

export function ReadingReview({ readings, onApprove, onReject }: ReadingReviewProps) {
  const [selectedReading, setSelectedReading] = useState<Reading | null>(null);
  const [reviewNote, setReviewNote] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  const filteredReadings = readings.filter((reading) =>
    Object.values(reading).some((value) =>
      value.toString().toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Reading Reviews</h2>
          <p className="text-muted-foreground">Review and approve pending meter readings</p>
        </div>
        <div className="relative w-64">
          <Input
            placeholder="Search readings..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredReadings.map((reading) => (
          <motion.div
            key={reading.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <Card className="p-6 space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-semibold">Meter {reading.meterId}</h3>
                  <p className="text-sm text-muted-foreground">{reading.type}</p>
                </div>
                <AlertTriangle className="h-5 w-5 text-orange-500" />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Reading Value:</span>
                  <span className="font-medium">{reading.value}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Location:</span>
                  <span className="font-medium">{reading.location}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Engineer:</span>
                  <span className="font-medium">{reading.engineer}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Time:</span>
                  <span className="font-medium">
                    {format(new Date(reading.timestamp), "PPp")}
                  </span>
                </div>
              </div>

              {reading.imageUrl && (
                <div className="relative h-32 rounded-lg overflow-hidden bg-muted">
                  <img
                    src={reading.imageUrl}
                    alt="Meter reading"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              {reading.notes && (
                <div className="text-sm">
                  <p className="text-muted-foreground font-medium">Notes:</p>
                  <p>{reading.notes}</p>
                </div>
              )}

              <div className="flex gap-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full gap-2"
                      onClick={() => {
                        setSelectedReading(reading);
                        setReviewNote("");
                      }}
                    >
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      Approve
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Approve Reading</DialogTitle>
                      <DialogDescription>
                        Add a note to approve this meter reading.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <Textarea
                        placeholder="Add review notes..."
                        value={reviewNote}
                        onChange={(e) => setReviewNote(e.target.value)}
                      />
                      <Button
                        className="w-full gap-2"
                        onClick={() => {
                          if (selectedReading) {
                            onApprove(selectedReading.id, reviewNote);
                          }
                        }}
                      >
                        <CheckCircle className="h-4 w-4" />
                        Confirm Approval
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>

                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full gap-2"
                      onClick={() => {
                        setSelectedReading(reading);
                        setReviewNote("");
                      }}
                    >
                      <XCircle className="h-4 w-4 text-red-500" />
                      Reject
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Reject Reading</DialogTitle>
                      <DialogDescription>
                        Add a note to explain why this reading is being rejected.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <Textarea
                        placeholder="Add rejection reason..."
                        value={reviewNote}
                        onChange={(e) => setReviewNote(e.target.value)}
                      />
                      <Button
                        variant="destructive"
                        className="w-full gap-2"
                        onClick={() => {
                          if (selectedReading) {
                            onReject(selectedReading.id, reviewNote);
                          }
                        }}
                      >
                        <XCircle className="h-4 w-4" />
                        Confirm Rejection
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </Card>
          </motion.div>
        ))}

        {filteredReadings.length === 0 && (
          <div className="col-span-full text-center py-12">
            <div className="mx-auto w-24 h-24 rounded-full bg-muted flex items-center justify-center mb-4">
              <CheckCircle className="h-12 w-12 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold">No Pending Reviews</h3>
            <p className="text-muted-foreground">
              All meter readings have been reviewed
            </p>
          </div>
        )}
      </div>
    </div>
  );
}