import { useState } from "react";
import { DashboardLayout } from "./layout";
import { MeterReadingForm } from "@/components/meter-reading/meter-form";
import { DataTable } from "./data-table";
import { useStore } from "@/lib/store";
import { useAuth } from "@/lib/auth";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Plus, Download, Filter, Search, BarChart2 } from "lucide-react";
import { TimelineChart } from "./timeline-chart";

export function ReadingsView() {
  const { readings, meters } = useStore();
  const { user } = useAuth();
  const [isAddingReading, setIsAddingReading] = useState(false);
  const [selectedMeterId, setSelectedMeterId] = useState<string>("all");
  const [selectedEngineer, setSelectedEngineer] = useState<string>("all");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");

  // Get unique engineers from readings
  const engineers = Array.from(new Set(readings.map(r => r.engineer)));

  // Filter readings based on selections
  const filteredReadings = readings.filter(reading => {
    const meterMatch = selectedMeterId === "all" || reading.meterId === selectedMeterId;
    const engineerMatch = selectedEngineer === "all" || reading.engineer === selectedEngineer;
    const statusMatch = selectedStatus === "all" || reading.reviewStatus === selectedStatus;
    return meterMatch && engineerMatch && statusMatch;
  });

  const columns = [
    { 
      header: "Meter ID",
      accessorKey: "meterId",
      cell: (value: string) => <div className="font-medium">{value}</div>,
    },
    {
      header: "Type",
      accessorKey: "type",
      cell: (value: string) => <div className="capitalize">{value}</div>,
    },
    {
      header: "Value",
      accessorKey: "value",
      cell: (value: number, row: any) => (
        <div className="font-medium">
          {value} {row.type === "temperature" ? "°C" : "kW"}
        </div>
      ),
    },
    {
      header: "Location",
      accessorKey: "location",
      cell: (value: string) => <div className="capitalize">{value.replace(/_/g, " ")}</div>,
    },
    {
      header: "Engineer",
      accessorKey: "engineer",
      cell: (value: string) => <div className="text-muted-foreground">{value}</div>,
    },
    {
      header: "Date",
      accessorKey: "timestamp",
      cell: (value: string) => format(new Date(value), "PPp"),
    },
    {
      header: "Status",
      accessorKey: "reviewStatus",
      cell: (value: string) => (
        <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
          value === "pending"
            ? "bg-yellow-100 text-yellow-800"
            : value === "approved"
            ? "bg-green-100 text-green-800"
            : value === "rejected"
            ? "bg-red-100 text-red-800"
            : "bg-blue-100 text-blue-800"
        }`}>
          {value || "completed"}
        </div>
      ),
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Meter Readings</h1>
            <p className="text-muted-foreground">View and manage all meter readings</p>
          </div>
          <Dialog open={isAddingReading} onOpenChange={setIsAddingReading}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Add Reading
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Submit New Reading</DialogTitle>
                <DialogDescription>
                  Enter the meter details and current reading value.
                </DialogDescription>
              </DialogHeader>
              <MeterReadingForm onSuccess={() => setIsAddingReading(false)} />
            </DialogContent>
          </Dialog>
        </div>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="space-y-1">
              <h2 className="text-lg font-semibold">Reading Timeline</h2>
              <p className="text-sm text-muted-foreground">Daily meter reading activity</p>
            </div>
            <BarChart2 className="h-5 w-5 text-muted-foreground" />
          </div>
          <TimelineChart data={filteredReadings} />
        </Card>

        <div className="rounded-lg border bg-card">
          <div className="p-6 space-y-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-col sm:flex-row gap-4">
                <Select value={selectedMeterId} onValueChange={setSelectedMeterId}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by Meter" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Meters</SelectItem>
                    {meters.map(meter => (
                      <SelectItem key={meter.id} value={meter.id}>
                        {meter.id} - {meter.location}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={selectedEngineer} onValueChange={setSelectedEngineer}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by Engineer" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Engineers</SelectItem>
                    {engineers.map(engineer => (
                      <SelectItem key={engineer} value={engineer}>
                        {engineer}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="pending">Pending Review</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                Export
              </Button>
            </div>

            <DataTable
              data={filteredReadings}
              columns={columns}
              searchPlaceholder="Search readings..."
            />
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}