import { DashboardLayout } from "./layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import { format } from "date-fns";
import { TimelineChart } from "./timeline-chart";
import { Download, Filter, BarChart2 } from "lucide-react";

export function ReportsView() {
  const { readings } = useStore();

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Reports & Analytics</h1>
            <p className="text-muted-foreground">View and analyze meter reading data</p>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" className="gap-2">
              <Filter className="h-4 w-4" />
              Filter
            </Button>
            <Button variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
          </div>
        </div>

        <div className="grid gap-6">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="space-y-1">
                <h2 className="text-lg font-semibold">Reading Timeline</h2>
                <p className="text-sm text-muted-foreground">Daily meter reading activity</p>
              </div>
              <BarChart2 className="h-5 w-5 text-muted-foreground" />
            </div>
            <TimelineChart data={readings} />
          </Card>

          {/* Add more report sections here */}
        </div>
      </div>
    </DashboardLayout>
  );
}