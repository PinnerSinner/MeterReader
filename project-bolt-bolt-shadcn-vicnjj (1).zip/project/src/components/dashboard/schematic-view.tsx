import { DashboardLayout } from "./layout";
import { FactorySchematic } from "@/components/schematic/factory-schematic";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { MeterReadingForm } from "@/components/meter-reading/meter-form";

export function SchematicView() {
  const [isAddingReading, setIsAddingReading] = useState(false);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold">Factory Schematic</h1>
          <p className="text-muted-foreground">Interactive map of meter locations</p>
        </div>

        <div className="rounded-lg border bg-card p-6">
          <FactorySchematic
            onMeterClick={() => setIsAddingReading(true)}
          />
        </div>

        <Dialog open={isAddingReading} onOpenChange={setIsAddingReading}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Submit New Reading</DialogTitle>
              <DialogDescription>
                Enter the meter details and current reading value.
              </DialogDescription>
            </DialogHeader>
            <MeterReadingForm onSuccess={() => setIsAddingReading(false)} />
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}