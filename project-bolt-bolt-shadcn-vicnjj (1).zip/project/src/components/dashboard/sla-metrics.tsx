import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Gauge, Clock, CheckCircle2, AlertTriangle } from "lucide-react";
import { motion } from "framer-motion";

interface SLAMetricsProps {
  metrics: {
    responseTime: number;
    uptime: number;
    accuracy: number;
    compliance: number;
  };
}

export function SLAMetrics({ metrics }: SLAMetricsProps) {
  const getStatusColor = (value: number) => {
    if (value >= 95) return "text-green-500";
    if (value >= 85) return "text-yellow-500";
    return "text-red-500";
  };

  const getProgressColor = (value: number) => {
    if (value >= 95) return "bg-green-500";
    if (value >= 85) return "bg-yellow-500";
    return "bg-red-500";
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-semibold">Service Level Metrics</h3>
          <p className="text-sm text-muted-foreground">System performance and reliability</p>
        </div>
      </div>

      <div className="space-y-6">
        {/* Response Time */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Response Time</span>
            </div>
            <span className={`text-sm font-bold ${getStatusColor(metrics.responseTime)}`}>
              {metrics.responseTime}%
            </span>
          </div>
          <Progress value={metrics.responseTime} className={getProgressColor(metrics.responseTime)} />
          <p className="text-xs text-muted-foreground">Average system response time within SLA</p>
        </div>

        {/* System Uptime */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gauge className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">System Uptime</span>
            </div>
            <span className={`text-sm font-bold ${getStatusColor(metrics.uptime)}`}>
              {metrics.uptime}%
            </span>
          </div>
          <Progress value={metrics.uptime} className={getProgressColor(metrics.uptime)} />
          <p className="text-xs text-muted-foreground">System availability in the last 30 days</p>
        </div>

        {/* Data Accuracy */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Data Accuracy</span>
            </div>
            <span className={`text-sm font-bold ${getStatusColor(metrics.accuracy)}`}>
              {metrics.accuracy}%
            </span>
          </div>
          <Progress value={metrics.accuracy} className={getProgressColor(metrics.accuracy)} />
          <p className="text-xs text-muted-foreground">Reading accuracy rate based on validations</p>
        </div>

        {/* Compliance Rate */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Compliance Rate</span>
            </div>
            <span className={`text-sm font-bold ${getStatusColor(metrics.compliance)}`}>
              {metrics.compliance}%
            </span>
          </div>
          <Progress value={metrics.compliance} className={getProgressColor(metrics.compliance)} />
          <p className="text-xs text-muted-foreground">Readings submitted within schedule</p>
        </div>
      </div>
    </Card>
  );
}