import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  gradient: "purple" | "green" | "blue" | "orange";
  trend?: {
    value: number;
    isPositive: boolean;
  };
  className?: string;
}

export function StatsCard({
  title,
  value,
  icon,
  gradient,
  trend,
  className,
}: StatsCardProps) {
  return (
    <motion.div
      whileHover={{ y: -2, transition: { duration: 0.2 } }}
      className={cn("relative", className)}
    >
      <Card className={cn(
        "p-6 overflow-hidden border-0",
        `gradient-${gradient}`,
      )}>
        <div className="flex items-center gap-4">
          <div className="p-3 rounded-xl bg-white/10">
            {icon}
          </div>
          <div className="space-y-1">
            <p className="text-sm font-medium text-white/80">
              {title}
            </p>
            <div className="flex items-baseline gap-2">
              <h2 className="text-3xl font-bold tracking-tight text-white">
                {value}
              </h2>
              {trend && (
                <span className={cn(
                  "text-sm font-medium",
                  trend.isPositive ? "text-green-300" : "text-red-300"
                )}>
                  {trend.isPositive ? "+" : "-"}{trend.value}%
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute -right-4 -bottom-4 w-32 h-32 rounded-full bg-white/5" />
        <div className="absolute -right-2 -bottom-2 w-24 h-24 rounded-full bg-white/10" />
      </Card>
    </motion.div>
  );
}