import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import { Reading } from "@/lib/store";
import { format, startOfDay, endOfDay, eachDayOfInterval, subDays } from "date-fns";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface TimelineChartProps {
  data: Reading[];
}

export function TimelineChart({ data }: TimelineChartProps) {
  // Get the last 7 days
  const dates = eachDayOfInterval({
    start: subDays(new Date(), 6),
    end: new Date(),
  });

  // Group readings by day
  const dailyReadings = dates.map(date => {
    const dayStart = startOfDay(date);
    const dayEnd = endOfDay(date);
    return data.filter(reading => {
      const readingDate = new Date(reading.timestamp);
      return readingDate >= dayStart && readingDate <= dayEnd;
    }).length;
  });

  const chartData = {
    labels: dates.map(date => format(date, "EEE")),
    datasets: [
      {
        label: "Readings",
        data: dailyReadings,
        fill: true,
        backgroundColor: "rgba(99, 102, 241, 0.1)",
        borderColor: "rgb(99, 102, 241)",
        tension: 0.4,
        pointRadius: 4,
        pointBackgroundColor: "rgb(99, 102, 241)",
        pointBorderColor: "white",
        pointBorderWidth: 2,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: "rgb(17, 24, 39)",
        titleColor: "rgb(243, 244, 246)",
        bodyColor: "rgb(243, 244, 246)",
        padding: 12,
        borderColor: "rgb(55, 65, 81)",
        borderWidth: 1,
        titleFont: {
          size: 14,
          weight: "bold",
        },
        bodyFont: {
          size: 13,
        },
        bodySpacing: 4,
        callbacks: {
          title: (items: any[]) => format(dates[items[0].dataIndex], "PPP"),
          label: (item: any) => `${item.formattedValue} readings`,
        },
      },
    },
    scales: {
      x: {
        grid: {
          display: false,
        },
        ticks: {
          color: "rgb(156, 163, 175)",
        },
      },
      y: {
        beginAtZero: true,
        grid: {
          color: "rgb(243, 244, 246, 0.1)",
        },
        ticks: {
          color: "rgb(156, 163, 175)",
          stepSize: 1,
        },
      },
    },
  };

  return (
    <div className="h-[300px]">
      <Line data={chartData} options={options} />
    </div>
  );
}