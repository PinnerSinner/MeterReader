import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useStore } from "@/lib/store";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";
import { Loader2, ImagePlus, X } from "lucide-react";

const METER_TYPES = {
  electricity: { unit: "kW", min: 0, max: 1000 },
  water: { unit: "m³", min: 0, max: 1000 },
  gas: { unit: "m³", min: 0, max: 1000 },
  pressure: { unit: "bar", min: 0, max: 100 },
  temperature: { unit: "°C", min: -50, max: 150 },
} as const;

const formSchema = z.object({
  meterId: z.string().min(1, "Meter ID is required"),
  type: z.enum(["electricity", "water", "gas", "pressure", "temperature"] as const),
  reading: z.string().refine((val) => {
    const num = parseFloat(val);
    return !isNaN(num);
  }, "Invalid reading format"),
  location: z.string().min(1, "Location is required"),
  notes: z.string().optional(),
  needsReview: z.boolean().default(false),
  imageUrl: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface MeterReadingFormProps {
  onSuccess?: () => void;
}

export function MeterReadingForm({ onSuccess }: MeterReadingFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const { user } = useAuth();
  const { addReading, meters } = useStore();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      meterId: "",
      type: "electricity",
      reading: "",
      location: "",
      notes: "",
      needsReview: false,
      imageUrl: "",
    },
  });

  const selectedType = form.watch("type");

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const imageUrl = reader.result as string;
        setSelectedImage(imageUrl);
        form.setValue("imageUrl", imageUrl);
      };
      reader.readAsDataURL(file);
    }
  };

  async function onSubmit(values: FormValues) {
    try {
      setIsSubmitting(true);
      const reading = parseFloat(values.reading);
      const meterType = METER_TYPES[values.type];
      
      if (reading < meterType.min || reading > meterType.max) {
        toast.error("Invalid reading value", {
          description: `Value must be between ${meterType.min} and ${meterType.max} ${meterType.unit}`,
        });
        return;
      }

      addReading({
        ...values,
        engineer: user?.name || "Unknown Engineer",
        value: reading,
      });

      toast.success("Reading submitted successfully", {
        description: `Meter ${values.meterId} reading recorded.`,
      });

      form.reset();
      setSelectedImage(null);
      onSuccess?.();
    } catch (error) {
      toast.error("Failed to submit reading", {
        description: "Please try again.",
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid gap-6 md:grid-cols-2">
          <FormField
            control={form.control}
            name="meterId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Meter ID</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select meter" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {meters.map((meter) => (
                      <SelectItem key={meter.id} value={meter.id}>
                        {meter.id} - {meter.location}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="type"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Meter Type</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select meter type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="electricity">Electricity</SelectItem>
                    <SelectItem value="water">Water</SelectItem>
                    <SelectItem value="gas">Gas</SelectItem>
                    <SelectItem value="pressure">Pressure</SelectItem>
                    <SelectItem value="temperature">Temperature</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="reading"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Reading Value</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Input 
                      type="number" 
                      step="0.01" 
                      placeholder={`Enter value in ${METER_TYPES[selectedType].unit}`}
                      {...field} 
                    />
                    <span className="absolute right-3 top-2.5 text-sm text-muted-foreground">
                      {METER_TYPES[selectedType].unit}
                    </span>
                  </div>
                </FormControl>
                <FormDescription>
                  Range: {METER_TYPES[selectedType].min} - {METER_TYPES[selectedType].max} {METER_TYPES[selectedType].unit}
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="location"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Location</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="main_production">Main Production Line</SelectItem>
                    <SelectItem value="cooling_system">Cooling System</SelectItem>
                    <SelectItem value="heating_unit">Heating Unit</SelectItem>
                    <SelectItem value="storage_area">Storage Area</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Notes (Optional)</FormLabel>
              <FormControl>
                <Input placeholder="Add any additional notes" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="imageUrl"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Image (Optional)</FormLabel>
              <FormControl>
                <div className="space-y-4">
                  {selectedImage ? (
                    <div className="relative rounded-lg overflow-hidden border">
                      <img
                        src={selectedImage}
                        alt="Reading"
                        className="w-full h-48 object-cover"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 right-2"
                        onClick={() => {
                          setSelectedImage(null);
                          field.onChange("");
                        }}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ) : (
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full h-48 flex flex-col gap-2"
                      onClick={() => document.getElementById("image-upload")?.click()}
                    >
                      <ImagePlus className="h-8 w-8 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">
                        Click to upload an image
                      </span>
                    </Button>
                  )}
                  <input
                    id="image-upload"
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleImageUpload}
                  />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="needsReview"
          render={({ field }) => (
            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
              <FormControl>
                <Checkbox
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
              <div className="space-y-1 leading-none">
                <FormLabel>Request Review</FormLabel>
                <FormDescription>
                  Check this if the reading needs review from an administrator
                </FormDescription>
              </div>
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Submitting...
            </>
          ) : (
            "Submit Reading"
          )}
        </Button>
      </form>
    </Form>
  );
}