import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Gauge, Info } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const meters = [
  { id: "M001", type: "Electricity", location: "Main Production Line", x: 20, y: 30 },
  { id: "M002", type: "Water", location: "Cooling System", x: 40, y: 60 },
  { id: "M003", type: "Gas", location: "Heating Unit", x: 60, y: 40 },
  { id: "M004", type: "Pressure", location: "Compressor Room", x: 80, y: 70 },
  { id: "M005", type: "Temperature", location: "Storage Area", x: 30, y: 80 },
];

export function MeterSchematic() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Factory Floor Schematic</h2>
          <p className="text-sm text-muted-foreground">
            Interactive map of meter locations
          </p>
        </div>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline" size="icon">
                <Info className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Click on meters to view details</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
        {/* Grid Background */}
        <div className="absolute inset-0 bg-grid opacity-10" />
        
        {/* Factory Layout */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Factory Outline */}
          <path
            d="M10 10 L90 10 L90 90 L10 90 Z"
            stroke="currentColor"
            strokeWidth="0.5"
            strokeDasharray="2 2"
            fill="none"
          />
          
          {/* Internal Divisions */}
          <path
            d="M50 10 L50 90 M10 50 L90 50"
            stroke="currentColor"
            strokeWidth="0.25"
            strokeDasharray="2 2"
          />
        </svg>

        {/* Meters */}
        {meters.map((meter) => (
          <motion.div
            key={meter.id}
            className="absolute"
            style={{
              left: `${meter.x}%`,
              top: `${meter.y}%`,
              transform: 'translate(-50%, -50%)',
            }}
            whileHover={{ scale: 1.2 }}
          >
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8 rounded-full bg-background shadow-lg"
                  >
                    <Gauge className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <div className="space-y-1">
                    <p className="font-medium">{meter.id} - {meter.type}</p>
                    <p className="text-xs text-muted-foreground">{meter.location}</p>
                  </div>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </motion.div>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {meters.map((meter) => (
          <Card key={meter.id} className="p-4">
            <div className="flex items-center gap-3">
              <Gauge className="h-8 w-8 text-primary" />
              <div>
                <h3 className="font-medium">{meter.id}</h3>
                <p className="text-sm text-muted-foreground">{meter.type}</p>
                <p className="text-xs text-muted-foreground">{meter.location}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}