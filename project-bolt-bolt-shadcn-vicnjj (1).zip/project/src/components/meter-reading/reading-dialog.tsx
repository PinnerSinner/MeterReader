import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { MeterReadingForm } from "./meter-form"
import { PlusCircle } from "lucide-react"

export function ReadingDialog() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button size="lg" className="gap-2">
          <PlusCircle className="h-5 w-5" />
          Add Reading
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Submit Meter Reading</DialogTitle>
          <DialogDescription>
            Enter the meter details and current reading value below.
          </DialogDescription>
        </DialogHeader>
        <MeterReadingForm />
      </DialogContent>
    </Dialog>
  )
}