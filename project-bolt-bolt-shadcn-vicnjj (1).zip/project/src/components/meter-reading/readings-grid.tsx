import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Download, Search, FileText } from "lucide-react";
import { useStore } from "@/lib/store";
import { format } from "date-fns";

export function ReadingsDataGrid() {
  const readings = useStore((state) => state.readings);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredReadings = readings.filter((reading) =>
    Object.values(reading).some((value) =>
      value.toString().toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Reading History</h2>
          <p className="text-sm text-muted-foreground">
            View and analyze past meter readings
          </p>
        </div>
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          Export
        </Button>
      </div>

      <div className="folder-card">
        <div className="folder-header flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{filteredReadings.length} Readings</span>
          </div>
          <div className="relative w-64">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search readings..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>

        <div className="rounded-md border mt-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Meter ID</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Reading</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Timestamp</TableHead>
                <TableHead>Engineer</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredReadings.map((reading) => (
                <TableRow key={reading.id}>
                  <TableCell className="font-medium">{reading.meterId}</TableCell>
                  <TableCell>{reading.type}</TableCell>
                  <TableCell>{reading.value}</TableCell>
                  <TableCell>{reading.location}</TableCell>
                  <TableCell>{format(new Date(reading.timestamp), "PPp")}</TableCell>
                  <TableCell>{reading.engineer}</TableCell>
                </TableRow>
              ))}
              {filteredReadings.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-6 text-muted-foreground">
                    No readings found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}