import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  Gauge,
  Factory,
  Users,
  Activity,
  ChevronRight,
} from "lucide-react";
import { useAuth } from "@/lib/auth";

const engineerLinks = [
  {
    title: "Overview",
    icon: LayoutDashboard,
    href: "/engineer",
  },
  {
    title: "Readings",
    icon: Gauge,
    href: "/engineer/readings",
  },
  {
    title: "Schematic",
    icon: Factory,
    href: "/engineer/schematic",
  },
];

const adminLinks = [
  {
    title: "Overview",
    icon: LayoutDashboard,
    href: "/admin",
  },
  {
    title: "Analytics",
    icon: Activity,
    href: "/admin/analytics",
  },
  {
    title: "Users",
    icon: Users,
    href: "/admin/users",
  },
];

export function Sidebar() {
  const { user } = useAuth();
  const location = useLocation();
  const links = user?.role === "admin" ? adminLinks : engineerLinks;

  return (
    <div className="pb-12 min-h-screen">
      <div className="space-y-4 py-4">
        <div className="px-3 py-2">
          <div className="flex items-center gap-2 mb-8 px-2">
            <Factory className="h-6 w-6 text-primary" />
            <h2 className="text-lg font-semibold">MeterReader+</h2>
          </div>
          <div className="space-y-1">
            {links.map((link) => (
              <Link key={link.href} to={link.href}>
                <Button
                  variant={location.pathname === link.href ? "secondary" : "ghost"}
                  className={cn(
                    "w-full justify-start gap-2 group",
                    location.pathname === link.href && "bg-primary text-primary-foreground hover:bg-primary/90"
                  )}
                >
                  <link.icon className="h-4 w-4" />
                  {link.title}
                  <ChevronRight className={cn(
                    "ml-auto h-4 w-4 opacity-0 -translate-x-2 transition-all",
                    location.pathname === link.href ? "opacity-100 translate-x-0" : "group-hover:opacity-100 group-hover:translate-x-0"
                  )} />
                </Button>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}