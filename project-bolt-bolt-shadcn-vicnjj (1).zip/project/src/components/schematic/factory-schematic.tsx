import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/store";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { motion } from "framer-motion";
import { Gauge, Info, ZoomIn, ZoomOut } from "lucide-react";

interface SchematicProps {
  isEditable?: boolean;
  onMeterClick?: (meterId: string) => void;
}

export function FactorySchematic({ isEditable = false, onMeterClick }: SchematicProps) {
  const { meters } = useStore();
  const [scale, setScale] = useState(1);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Factory Floor Schematic</h2>
          <p className="text-sm text-muted-foreground">
            {isEditable ? "Design and edit factory layout" : "Interactive map of meter locations"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setScale(s => Math.max(0.5, s - 0.1))}
          >
            <ZoomOut className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setScale(s => Math.min(2, s + 0.1))}
          >
            <ZoomIn className="h-4 w-4" />
          </Button>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon">
                  <Info className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{isEditable ? "Edit mode active" : "Click meters to view details"}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      <Card className="relative aspect-video bg-muted/50 overflow-hidden p-6">
        <div className="absolute inset-0 bg-grid opacity-10" />
        
        <div 
          className="relative w-full h-full"
          style={{ transform: `scale(${scale})`, transformOrigin: "center" }}
        >
          {/* Factory Layout */}
          <svg
            className="absolute inset-0 w-full h-full"
            viewBox="0 0 800 600"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Factory Outline */}
            <path
              d="M100 100 L700 100 L700 500 L100 500 Z"
              stroke="currentColor"
              strokeWidth="2"
              strokeDasharray="5 5"
              fill="none"
            />
            
            {/* Internal Divisions */}
            <path
              d="M400 100 L400 500 M100 300 L700 300"
              stroke="currentColor"
              strokeWidth="1"
              strokeDasharray="5 5"
            />

            {/* Room Labels */}
            <text x="250" y="200" className="text-xs fill-current opacity-50">Production Area</text>
            <text x="550" y="200" className="text-xs fill-current opacity-50">Storage</text>
            <text x="250" y="400" className="text-xs fill-current opacity-50">Maintenance</text>
            <text x="550" y="400" className="text-xs fill-current opacity-50">Utilities</text>
          </svg>

          {/* Meters */}
          {meters.map((meter) => (
            <TooltipProvider key={meter.id}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <motion.div
                    className="absolute"
                    style={{
                      left: `${(meter.position.x / 800) * 100}%`,
                      top: `${(meter.position.y / 600) * 100}%`,
                    }}
                    whileHover={{ scale: 1.2 }}
                    onClick={() => onMeterClick?.(meter.id)}
                  >
                    <div className={`
                      -translate-x-1/2 -translate-y-1/2
                      w-8 h-8 rounded-full
                      flex items-center justify-center
                      ${meter.maintenanceRequired 
                        ? "bg-red-100 text-red-600" 
                        : "bg-green-100 text-green-600"}
                      cursor-pointer
                      transition-colors
                    `}>
                      <Gauge className="h-4 w-4" />
                    </div>
                  </motion.div>
                </TooltipTrigger>
                <TooltipContent>
                  <div className="space-y-1">
                    <p className="font-medium">{meter.id}</p>
                    <p className="text-xs text-muted-foreground">{meter.type}</p>
                    <p className="text-xs text-muted-foreground">{meter.location}</p>
                  </div>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ))}
        </div>

        {/* Legend */}
        <div className="absolute bottom-4 right-4 bg-background/80 backdrop-blur-sm p-3 rounded-lg border shadow-sm">
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500" />
              <span>Active</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <span>Maintenance</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Meter List */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {meters.map((meter) => (
          <Card key={meter.id} className="p-4">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-full ${
                meter.maintenanceRequired ? "bg-red-100" : "bg-green-100"
              }`}>
                <Gauge className={`h-4 w-4 ${
                  meter.maintenanceRequired ? "text-red-600" : "text-green-600"
                }`} />
              </div>
              <div>
                <h3 className="font-medium">{meter.id}</h3>
                <p className="text-sm text-muted-foreground">{meter.type}</p>
                <p className="text-xs text-muted-foreground">{meter.location}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}