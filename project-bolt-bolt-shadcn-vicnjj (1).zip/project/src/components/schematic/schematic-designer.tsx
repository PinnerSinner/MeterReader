import { useState, useCallback } from "react";
import { Stage, Layer, Rect, Circle, Line } from "react-konva";
import { useDropzone } from "react-dropzone";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Pen,
  Square,
  Circle as CircleIcon,
  Move,
  Gauge,
  Save,
  Upload,
  Eraser,
  Undo,
  Redo,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import useImage from "use-image";

const TOOLS = {
  PEN: "pen",
  RECTANGLE: "rectangle",
  CIRCLE: "circle",
  METER: "meter",
  MOVE: "move",
  ERASER: "eraser",
} as const;

type Tool = typeof TOOLS[keyof typeof TOOLS];

interface Point {
  x: number;
  y: number;
}

interface Shape {
  id: string;
  tool: Tool;
  points?: Point[];
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  radius?: number;
}

interface BackgroundImageProps {
  src: string;
}

function BackgroundImage({ src }: BackgroundImageProps) {
  const [image] = useImage(src);
  return <image image={image} opacity={0.5} />;
}

export function SchematicDesigner() {
  const [selectedTool, setSelectedTool] = useState<Tool>(TOOLS.PEN);
  const [shapes, setShapes] = useState<Shape[]>([]);
  const [currentShape, setCurrentShape] = useState<Shape | null>(null);
  const [history, setHistory] = useState<Shape[][]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [scale, setScale] = useState(1);
  const [backgroundImage, setBackgroundImage] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setBackgroundImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  }, []);

  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.svg']
    },
    onDrop
  });

  const addToHistory = useCallback((newShapes: Shape[]) => {
    setHistory(prev => [...prev.slice(0, historyIndex + 1), newShapes]);
    setHistoryIndex(prev => prev + 1);
  }, [historyIndex]);

  const handleUndo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(prev => prev - 1);
      setShapes(history[historyIndex - 1]);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(prev => prev + 1);
      setShapes(history[historyIndex + 1]);
    }
  };

  const handleMouseDown = (e: any) => {
    const pos = e.target.getStage().getPointerPosition();
    const shape: Shape = {
      id: crypto.randomUUID(),
      tool: selectedTool,
      points: selectedTool === TOOLS.PEN ? [pos] : undefined,
      x: pos.x,
      y: pos.y,
    };
    setCurrentShape(shape);
  };

  const handleMouseMove = (e: any) => {
    if (!currentShape) return;

    const pos = e.target.getStage().getPointerPosition();

    if (selectedTool === TOOLS.PEN) {
      setCurrentShape({
        ...currentShape,
        points: [...(currentShape.points || []), pos],
      });
    } else if (selectedTool === TOOLS.RECTANGLE) {
      setCurrentShape({
        ...currentShape,
        width: pos.x - (currentShape.x || 0),
        height: pos.y - (currentShape.y || 0),
      });
    } else if (selectedTool === TOOLS.CIRCLE) {
      const dx = pos.x - (currentShape.x || 0);
      const dy = pos.y - (currentShape.y || 0);
      setCurrentShape({
        ...currentShape,
        radius: Math.sqrt(dx * dx + dy * dy),
      });
    }
  };

  const handleMouseUp = () => {
    if (!currentShape) return;

    const newShapes = [...shapes, currentShape];
    setShapes(newShapes);
    addToHistory(newShapes);
    setCurrentShape(null);
  };

  return (
    <div className="h-[calc(100vh-10rem)] flex gap-4">
      {/* Tools Panel */}
      <Card className="w-64 flex flex-col">
        <CardHeader>
          <CardTitle>Schematic Tools</CardTitle>
          <CardDescription>Design your factory layout</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-2">
            <Button
              variant={selectedTool === TOOLS.PEN ? "default" : "outline"}
              size="icon"
              onClick={() => setSelectedTool(TOOLS.PEN)}
              title="Pen Tool"
            >
              <Pen className="h-4 w-4" />
            </Button>
            <Button
              variant={selectedTool === TOOLS.RECTANGLE ? "default" : "outline"}
              size="icon"
              onClick={() => setSelectedTool(TOOLS.RECTANGLE)}
              title="Rectangle Tool"
            >
              <Square className="h-4 w-4" />
            </Button>
            <Button
              variant={selectedTool === TOOLS.CIRCLE ? "default" : "outline"}
              size="icon"
              onClick={() => setSelectedTool(TOOLS.CIRCLE)}
              title="Circle Tool"
            >
              <CircleIcon className="h-4 w-4" />
            </Button>
            <Button
              variant={selectedTool === TOOLS.METER ? "default" : "outline"}
              size="icon"
              onClick={() => setSelectedTool(TOOLS.METER)}
              title="Add Meter"
            >
              <Gauge className="h-4 w-4" />
            </Button>
            <Button
              variant={selectedTool === TOOLS.MOVE ? "default" : "outline"}
              size="icon"
              onClick={() => setSelectedTool(TOOLS.MOVE)}
              title="Move Tool"
            >
              <Move className="h-4 w-4" />
            </Button>
            <Button
              variant={selectedTool === TOOLS.ERASER ? "default" : "outline"}
              size="icon"
              onClick={() => setSelectedTool(TOOLS.ERASER)}
              title="Eraser Tool"
            >
              <Eraser className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-2">
            <Label>History</Label>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={handleUndo}
                disabled={historyIndex <= 0}
              >
                <Undo className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={handleRedo}
                disabled={historyIndex >= history.length - 1}
              >
                <Redo className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Zoom</Label>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setScale(s => Math.max(0.5, s - 0.1))}
              >
                <ZoomOut className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setScale(s => Math.min(2, s + 0.1))}
              >
                <ZoomIn className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Import Layout</Label>
            <div {...getRootProps()} className="cursor-pointer">
              <input {...getInputProps()} />
              <Button variant="outline" className="w-full gap-2">
                <Upload className="h-4 w-4" />
                Upload Blueprint
              </Button>
            </div>
          </div>

          <Button className="w-full gap-2">
            <Save className="h-4 w-4" />
            Save Layout
          </Button>
        </CardContent>
      </Card>

      {/* Drawing Area */}
      <Card className="flex-1">
        <CardContent className="p-0 relative h-full">
          <Stage
            width={800}
            height={600}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            scale={{ x: scale, y: scale }}
          >
            <Layer>
              {/* Background Image */}
              {backgroundImage && (
                <BackgroundImage src={backgroundImage} />
              )}

              {/* Existing Shapes */}
              {shapes.map((shape) => {
                if (shape.tool === TOOLS.PEN && shape.points) {
                  return (
                    <Line
                      key={shape.id}
                      points={shape.points.flatMap(p => [p.x, p.y])}
                      stroke="#000"
                      strokeWidth={2}
                    />
                  );
                } else if (shape.tool === TOOLS.RECTANGLE) {
                  return (
                    <Rect
                      key={shape.id}
                      x={shape.x}
                      y={shape.y}
                      width={shape.width}
                      height={shape.height}
                      stroke="#000"
                      strokeWidth={2}
                    />
                  );
                } else if (shape.tool === TOOLS.CIRCLE) {
                  return (
                    <Circle
                      key={shape.id}
                      x={shape.x}
                      y={shape.y}
                      radius={shape.radius}
                      stroke="#000"
                      strokeWidth={2}
                    />
                  );
                }
                return null;
              })}

              {/* Current Shape */}
              {currentShape && (
                <>
                  {currentShape.tool === TOOLS.PEN && currentShape.points && (
                    <Line
                      points={currentShape.points.flatMap(p => [p.x, p.y])}
                      stroke="#000"
                      strokeWidth={2}
                    />
                  )}
                  {currentShape.tool === TOOLS.RECTANGLE && (
                    <Rect
                      x={currentShape.x}
                      y={currentShape.y}
                      width={currentShape.width}
                      height={currentShape.height}
                      stroke="#000"
                      strokeWidth={2}
                    />
                  )}
                  {currentShape.tool === TOOLS.CIRCLE && (
                    <Circle
                      x={currentShape.x}
                      y={currentShape.y}
                      radius={currentShape.radius}
                      stroke="#000"
                      strokeWidth={2}
                    />
                  )}
                </>
              )}
            </Layer>
          </Stage>
        </CardContent>
      </Card>
    </div>
  );
}