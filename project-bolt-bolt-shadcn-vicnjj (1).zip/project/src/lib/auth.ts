import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type UserRole = 'engineer' | 'admin';

interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string, role: UserRole) => Promise<void>;
  logout: () => void;
}

// Mock user database
const MOCK_USERS = [
  {
    id: '1',
    email: 'engineer@ngfe.com',
    password: 'engineer123',
    name: 'John Engineer',
    role: 'engineer' as UserRole,
  },
  {
    id: '2',
    email: 'admin@ngfe.com',
    password: 'admin123',
    name: 'Sarah Admin',
    role: 'admin' as UserRole,
  },
];

export const useAuth = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      login: async (email: string, password: string, role: UserRole) => {
        const user = MOCK_USERS.find(
          (u) => u.email === email && u.password === password && u.role === role
        );

        if (!user) {
          throw new Error('Invalid credentials');
        }

        const { password: _, ...userWithoutPassword } = user;
        set({ user: userWithoutPassword, isAuthenticated: true });
      },
      logout: () => {
        set({ user: null, isAuthenticated: false });
      },
    }),
    {
      name: 'auth-storage',
    }
  )
);