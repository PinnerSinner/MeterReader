import { Activity } from "./store";
import { format } from "date-fns";

export function exportToCSV(activities: Activity[]) {
  // Define CSV headers
  const headers = [
    "Type",
    "Title",
    "Description",
    "Engineer",
    "Timestamp",
    "Meter ID",
    "Reading Value",
    "Location",
  ];

  // Transform activities into CSV rows
  const rows = activities.map((activity) => [
    activity.type,
    activity.title,
    activity.description,
    activity.metadata?.reading?.engineer || "System",
    format(new Date(activity.timestamp), "yyyy-MM-dd HH:mm:ss"),
    activity.metadata?.reading?.meterId || "",
    activity.metadata?.reading?.reading || "",
    activity.metadata?.reading?.location || "",
  ]);

  // Combine headers and rows
  const csvContent = [
    headers.join(","),
    ...rows.map((row) => row.map((cell) => `"${cell}"`).join(",")),
  ].join("\n");

  // Create and trigger download
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  
  link.setAttribute("href", url);
  link.setAttribute("download", `activity-log-${format(new Date(), "yyyy-MM-dd")}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}