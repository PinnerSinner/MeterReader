import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { startOfDay, isToday } from 'date-fns';

interface Reading {
  id: string;
  meterId: string;
  type: string;
  value: number;
  location: string;
  engineer: string;
  timestamp: string;
  imageUrl?: string;
  notes?: string;
  needsReview?: boolean;
  reviewStatus?: 'pending' | 'approved' | 'rejected';
  reviewNote?: string;
  reviewedBy?: string;
  reviewedAt?: string;
}

interface Activity {
  id: string;
  type: 'reading_submitted' | 'maintenance_required' | 'alert' | 'review_requested' | 'review_completed' | 'user_added';
  title: string;
  description: string;
  timestamp: string;
  metadata?: {
    reading?: Reading;
    reviewStatus?: string;
    user?: User;
  };
}

interface Meter {
  id: string;
  type: string;
  location: string;
  lastReading?: Reading;
  maintenanceRequired: boolean;
  position: {
    x: number;
    y: number;
  };
}

interface User {
  id: string;
  name: string;
  email: string;
  role: 'engineer' | 'admin';
  status: 'active' | 'inactive';
  lastActive?: string;
}

interface StoreState {
  readings: Reading[];
  activities: Activity[];
  meters: Meter[];
  users: User[];
  addReading: (reading: Omit<Reading, 'id' | 'timestamp'>) => void;
  addActivity: (activity: Omit<Activity, 'id' | 'timestamp'>) => void;
  getTodaysReadings: () => Reading[];
  getActiveMeters: () => Meter[];
  getPendingMaintenance: () => Meter[];
  getPendingReviews: () => Reading[];
  updateReadingReview: (readingId: string, status: 'approved' | 'rejected', reviewNote: string, reviewedBy: string) => void;
  addUser: (user: Omit<User, 'id' | 'lastActive'>) => void;
  updateUser: (userId: string, updates: Partial<User>) => void;
  deleteUser: (userId: string) => void;
}

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      readings: [],
      activities: [],
      users: [],
      meters: [
        {
          id: 'MTR001',
          type: 'electricity',
          location: 'Main Production Line',
          maintenanceRequired: false,
          position: { x: 200, y: 150 },
        },
        {
          id: 'MTR002',
          type: 'water',
          location: 'Cooling System',
          maintenanceRequired: false,
          position: { x: 400, y: 150 },
        },
        {
          id: 'MTR003',
          type: 'gas',
          location: 'Heating Unit',
          maintenanceRequired: false,
          position: { x: 600, y: 150 },
        },
        {
          id: 'MTR004',
          type: 'temperature',
          location: 'Storage Area',
          maintenanceRequired: true,
          position: { x: 300, y: 350 },
        },
        {
          id: 'MTR005',
          type: 'pressure',
          location: 'Compressor Room',
          maintenanceRequired: false,
          position: { x: 500, y: 350 },
        },
      ],

      addReading: (reading) => {
        const newReading = {
          ...reading,
          id: crypto.randomUUID(),
          timestamp: new Date().toISOString(),
          reviewStatus: reading.needsReview ? 'pending' : undefined,
        };

        set((state) => ({
          readings: [newReading, ...state.readings],
          meters: state.meters.map(meter => 
            meter.id === reading.meterId 
              ? { ...meter, lastReading: newReading }
              : meter
          ),
        }));

        get().addActivity({
          type: 'reading_submitted',
          title: 'Meter Reading Submitted',
          description: `${reading.meterId} reading: ${reading.value}`,
          metadata: { reading: newReading },
        });

        if (reading.needsReview) {
          get().addActivity({
            type: 'review_requested',
            title: 'Review Requested',
            description: `Reading for ${reading.meterId} needs review`,
            metadata: { reading: newReading },
          });
        }
      },

      addActivity: (activity) => {
        const newActivity = {
          ...activity,
          id: crypto.randomUUID(),
          timestamp: new Date().toISOString(),
        };

        set((state) => ({
          activities: [newActivity, ...state.activities],
        }));
      },

      getTodaysReadings: () => {
        const today = startOfDay(new Date());
        return get().readings.filter((reading) =>
          isToday(new Date(reading.timestamp))
        );
      },

      getActiveMeters: () => {
        return get().meters.filter((meter) => !meter.maintenanceRequired);
      },

      getPendingMaintenance: () => {
        return get().meters.filter((meter) => meter.maintenanceRequired);
      },

      getPendingReviews: () => {
        return get().readings.filter((reading) => 
          reading.reviewStatus === 'pending'
        );
      },

      updateReadingReview: (readingId, status, reviewNote, reviewedBy) => {
        const timestamp = new Date().toISOString();
        
        set((state) => ({
          readings: state.readings.map((reading) =>
            reading.id === readingId
              ? {
                  ...reading,
                  reviewStatus: status,
                  reviewNote,
                  reviewedBy,
                  reviewedAt: timestamp,
                }
              : reading
          ),
        }));

        const reading = get().readings.find((r) => r.id === readingId);
        if (reading) {
          get().addActivity({
            type: 'review_completed',
            title: 'Reading Review Completed',
            description: `Reading for ${reading.meterId} was ${status}`,
            metadata: { 
              reading,
              reviewStatus: status,
            },
          });
        }
      },

      addUser: (user) => {
        const newUser = {
          ...user,
          id: crypto.randomUUID(),
          lastActive: new Date().toISOString(),
        };

        set((state) => ({
          users: [...state.users, newUser],
        }));

        get().addActivity({
          type: 'user_added',
          title: 'New User Added',
          description: `${newUser.name} (${newUser.role}) has been added to the system`,
          metadata: { user: newUser },
        });
      },

      updateUser: (userId, updates) => {
        set((state) => ({
          users: state.users.map((user) =>
            user.id === userId ? { ...user, ...updates } : user
          ),
        }));
      },

      deleteUser: (userId) => {
        set((state) => ({
          users: state.users.filter((user) => user.id !== userId),
        }));
      },
    }),
    {
      name: 'meter-reader-storage',
    }
  )
);

export type { Reading, Activity, Meter, User };